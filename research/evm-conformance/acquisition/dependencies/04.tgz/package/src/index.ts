import { EOFContainer, validateEOF } from './eof/container.ts'
import { EVMError } from './errors.ts'
import { EVM } from './evm.ts'
import { Message } from './message.ts'
import { getOpcodesForHF } from './opcodes/index.ts'
import {
  type AddPrecompile,
  type CustomPrecompile,
  type DeletePrecompile,
  MCLBLS,
  NobleBLS,
  NobleBN254,
  type PrecompileFunc,
  type PrecompileInput,
  RustBN254,
  getActivePrecompiles,
} from './precompiles/index.ts'
import { EVMMockBlockchain } from './types.ts'

import type { InterpreterStep } from './interpreter.ts'
import type {
  EVMBLSInterface,
  EVMBN254Interface,
  EVMInterface,
  EVMMockBlockchainInterface,
  EVMOpts,
  EVMResult,
  EVMRunCallOpts,
  EVMRunCodeOpts,
  ExecResult,
  Log,
  SelfdestructMap,
} from './types.ts'
export * from './logger.ts'

export type {
  AddPrecompile,
  CustomPrecompile,
  DeletePrecompile,
  EVMBLSInterface,
  EVMBN254Interface,
  EVMInterface,
  EVMMockBlockchainInterface,
  EVMOpts,
  EVMResult,
  EVMRunCallOpts,
  EVMRunCodeOpts,
  ExecResult,
  InterpreterStep,
  Log,
  SelfdestructMap,
  PrecompileFunc,
  PrecompileInput,
}

export {
  EOFContainer,
  EVM,
  EVMError,
  EVMMockBlockchain,
  getActivePrecompiles,
  getOpcodesForHF,
  MCLBLS,
  Message,
  NobleBLS,
  NobleBN254,
  RustBN254,
  validateEOF,
}

export * from './binaryTreeAccessWitness.ts'
export * from './constructors.ts'
export * from './eip7708.ts'
export * from './eip8037.ts'
export * from './params.ts'
