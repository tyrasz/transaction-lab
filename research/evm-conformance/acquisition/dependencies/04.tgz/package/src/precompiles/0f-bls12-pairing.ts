import { bytesToHex } from '@ethereumjs/util'

import { EVMError } from '../errors.ts'
import type { EVM } from '../evm.ts'
import { EVMErrorResult, OOGResult } from '../evm.ts'

import { leading16ZeroBytesCheck } from './bls12_381/index.ts'
import { getPrecompileName } from './index.ts'
import { gasLimitCheck, moduloLengthCheck } from './util.ts'

import type { ExecResult } from '../types.ts'
import type { PrecompileInput } from './types.ts'

/** BLS12-381 pairing check precompile (0x0f, EIP-2537). */
export async function precompile0f(opts: PrecompileInput): Promise<ExecResult> {
  const pName = getPrecompileName('11')
  const bls = (opts._EVM as EVM)['_bls']!

  const baseGas = opts.common.param('bls12381PairingBaseGas')

  // TODO: confirm that this is not a thing for the other precompiles
  if (opts.data.length === 0) {
    if (opts._debug !== undefined) {
      opts._debug(`${pName} failed: Empty input`)
    }
    return EVMErrorResult(
      new EVMError(EVMError.errorMessages.BLS_12_381_INPUT_EMPTY),
      opts.gasLimit,
    )
  }

  const gasUsedPerPair = opts.common.param('bls12381PairingPerPairGas')

  // TODO: For this precompile it is the only exception that the length check is placed before the
  // gas check. I will keep it there to not side-change the existing implementation, but we should
  // check (respectively Jochem can maybe have a word) if this is something intended or not
  if (!moduloLengthCheck(opts, 384, pName)) {
    return EVMErrorResult(
      new EVMError(EVMError.errorMessages.BLS_12_381_INVALID_INPUT_LENGTH),
      opts.gasLimit,
    )
  }

  const gasUsed = baseGas + gasUsedPerPair * BigInt(Math.floor(opts.data.length / 384))
  if (!gasLimitCheck(opts, gasUsed, pName)) {
    return OOGResult(opts.gasLimit)
  }

  // check for mandatory zero bytes
  const zeroByteRanges = [
    [0, 16],
    [64, 80],
    [128, 144],
    [192, 208],
    [256, 272],
    [320, 336],
  ]
  for (let k = 0; k < opts.data.length / 384; k++) {
    // zero bytes check
    const pairStart = 384 * k
    if (!leading16ZeroBytesCheck(opts, zeroByteRanges, pName, pairStart)) {
      return EVMErrorResult(
        new EVMError(EVMError.errorMessages.BLS_12_381_POINT_NOT_ON_CURVE),
        opts.gasLimit,
      )
    }
  }

  let returnValue
  try {
    returnValue = bls.pairingCheck(opts.data)
  } catch (e: unknown) {
    const error = e instanceof EVMError ? e : new EVMError(EVMError.errorMessages.REVERT)
    if (opts._debug !== undefined) {
      opts._debug(`${pName} failed: ${e instanceof Error ? e.message : undefined}`)
    }
    return EVMErrorResult(error, opts.gasLimit)
  }

  if (opts._debug !== undefined) {
    opts._debug(`${pName} return value=${bytesToHex(returnValue)}`)
  }

  return {
    executionGasUsed: gasUsed,
    returnValue,
  }
}
